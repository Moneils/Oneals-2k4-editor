# Oneals 2k4 Editor — Android Tablet graphical update

This Android Studio source project adds a **working touchscreen formation field** to the existing tablet editor. Choose a bundled PLAY base, select a formation, tap **DRAG PLAYERS ON FIELD**, drag the numbered markers, and tap Apply. Changes modify the actual 16-bit X/Z fields in the in-memory PLAY buffer. Cancel leaves the PLAY file unchanged. Multiple changes accumulate until **SAVE FINISHED PLAY**.

Also retained: 37 bundled PLAY files, formation/play browsing and length-limited renaming, precise coordinate entry, and experimental 50/90 class toggle.

**New experimental feature:** multi-breakpoint touchscreen route drawing, quantization to NFL 2K4 opcode 0x12, copy-on-write assignment allocation, descriptor/pointer update, and single-session save. Not yet verified in PCSX2. **Not implemented:** new/deleted formation or play records, formation/play creation and deletion. These are not represented as completed features. The original Windows version remains the feature-complete reference for route editing. No APK or PCSX2 validation was possible here.

Open the folder in Android Studio with Android SDK 35 and Java 17; build an APK from there. Source has not been compiled in Android Studio in this environment.


## ISO patching (Android SAF)
Tap **PATCH ISO**, select your original NFL 2K4 ISO, then choose a NEW output ISO location. The app validates the exact unmodified bundled PLAY bytes at the team offset embedded in the asset filename before writing. It streams the full ISO to the new document while replacing only that PLAY region, then reads the output back to verify resource bytes and file length. This may take time and require storage for a second full ISO. The original ISO is never opened for writing. If patching fails, delete the partial output file manually. **Not tested on Android hardware or in PCSX2**.
