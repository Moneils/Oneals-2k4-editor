package com.oneals.editor;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
  void error(String message) { android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show(); }
  static final int HEADER=32, BODY=0x13390, FORM=0x134, FSIZE=0xB4, AUX=0x245C, ASIZE=0x50, PLAY=0x33FC, PSIZE=0x60;
  final int bg=Color.rgb(16,23,35), panel=Color.rgb(30,43,60), white=Color.WHITE;
  byte[] data; String filename=""; boolean dirty=false; int formation=-1, play=-1;
  Spinner bases; LinearLayout formations, plays; TextView status, heading;
  String[] assetNames;
  static final int REQUEST_ISO=143, REQUEST_PATCHED_ISO=144;
  Uri selectedIso; boolean patchBusy=false;
  final ArrayList<Integer> displayedPlays=new ArrayList<>();
  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); buildUi();}
  TextView label(String t,int size){TextView v=new TextView(this);v.setText(t);v.setTextColor(white);v.setTextSize(size);v.setPadding(14,12,14,12);return v;}
  LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  void buildUi(){
    LinearLayout main=vertical(); main.setBackgroundColor(bg);setContentView(main);
    LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(12,8,12,8);main.addView(bar);
    TextView title=label("ONEALS 2K4 EDITOR",22);bar.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    Button save=new Button(this);save.setText("SAVE FINISHED PLAY");save.setOnClickListener(v->save());bar.addView(save);
    Button patch=new Button(this);patch.setText("PATCH ISO");patch.setOnClickListener(v->chooseIso());bar.addView(patch);
    LinearLayout columns=new LinearLayout(this);main.addView(columns,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout left=vertical();left.setBackgroundColor(panel);left.setPadding(12,8,12,8);columns.addView(left,new LinearLayout.LayoutParams(0,-1,1));
    left.addView(label("CHOOSE BASE",16));bases=new Spinner(this);left.addView(bases);
    try{assetNames=getAssets().list("playbooks");Arrays.sort(assetNames);bases.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,assetNames));}
    catch(Exception e){assetNames=new String[0];error(e.getMessage());}
    bases.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){if(dirty){new AlertDialog.Builder(MainActivity.this).setTitle("Unsaved changes").setMessage("Discard your unsaved changes and open another base?").setPositiveButton("Discard",(d,w)->load(pos)).setNegativeButton("Stay",(d,w)->bases.setSelection(Arrays.asList(assetNames).indexOf(filename))).show();}else load(pos);}});
    left.addView(label("FORMATIONS",16));ScrollView sc=new ScrollView(this);formations=vertical();sc.addView(formations);left.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout middle=vertical();middle.setPadding(12,8,12,8);columns.addView(middle,new LinearLayout.LayoutParams(0,-1,1));
    heading=label("Select a formation",18);middle.addView(heading);ScrollView ps=new ScrollView(this);plays=vertical();ps.addView(plays);middle.addView(ps,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout right=vertical();right.setBackgroundColor(panel);right.setPadding(18,12,18,12);columns.addView(right,new LinearLayout.LayoutParams(0,-1,1));
    right.addView(label("SESSION TOOLS",18));Button renameF=new Button(this);renameF.setText("RENAME FORMATION");renameF.setOnClickListener(v->rename(true));right.addView(renameF);
    Button renameP=new Button(this);renameP.setText("RENAME PLAY");renameP.setOnClickListener(v->rename(false));right.addView(renameP);
    Button positions=new Button(this);positions.setText("DRAG PLAYERS ON FIELD");positions.setOnClickListener(v->showFormationField());right.addView(positions);
    Button numeric=new Button(this);numeric.setText("PRECISE X / Z POSITIONS");numeric.setOnClickListener(v->editPositions());right.addView(numeric);
    Button route=new Button(this);route.setText("DRAW RECEIVER ROUTE");route.setOnClickListener(v->showRouteEditor());right.addView(route);
    Button playClass=new Button(this);playClass.setText("50 / 90 PLAY CLASS");playClass.setOnClickListener(v->editPlayClass());right.addView(playClass);
    right.addView(label("Drag player markers on the field; changes stay in memory until SAVE FINISHED PLAY. The 50/90 override is experimental.",14));
    right.addView(label("ISO patching: select original ISO, then choose a NEW output ISO. The bundled unmodified PLAY must match at the original offset. Formation/play creation and deletion are still pending.",14));
    status=label("Ready",13);main.addView(status);
  }
  int u16(int p){return (data[p]&255)|((data[p+1]&255)<<8);} int u32(int p){return u16(p)|(u16(p+2)<<16);}
  String name(int bodyField){int f=HEADER+bodyField;int relative=u32(f);int target=bodyField-1+relative;if(target<0x10840||target>=BODY||((target&1)!=0))throw new IllegalArgumentException("Invalid name pointer");int at=HEADER+target,end=at;while(end+1<data.length&&(data[end]!=0||data[end+1]!=0))end+=2;if(end+1>=data.length)throw new IllegalArgumentException("Unterminated name");return new String(data,at,end-at,StandardCharsets.UTF_16LE);}
  void load(int pos){try{String n=assetNames[pos];byte[] b;try(InputStream in=getAssets().open("playbooks/"+n);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int k;while((k=in.read(buf))!=-1)out.write(buf,0,k);b=out.toByteArray();}if(b.length!=HEADER+BODY||!"PLAY".equals(new String(b,0,4,StandardCharsets.US_ASCII)))throw new IOException("Invalid PLAY size/header");data=b;filename=n;dirty=false;formation=-1;play=-1;refreshFormations();status.setText("Loaded "+n+" • no changes");}catch(Exception e){error(e.toString());}}
  int formationCount(){return u32(HEADER+0x34);} int playCount(){return u32(HEADER+0x38);}
  void refreshFormations(){formations.removeAllViews();plays.removeAllViews();heading.setText("Select a formation");int count=formationCount();if(count<1||count>50)throw new IllegalArgumentException("Invalid formation count");for(int i=0;i<count;i++){final int idx=i;Button b=new Button(this);b.setAllCaps(false);b.setText(name(FORM+i*FSIZE));b.setOnClickListener(v->selectFormation(idx));formations.addView(b);}}
  void selectFormation(int idx){formation=idx;play=-1;displayedPlays.clear();plays.removeAllViews();heading.setText(name(FORM+idx*FSIZE));int count=playCount();for(int j=0;j<36;j++){int packed=u16(HEADER+AUX+idx*ASIZE+j*2);int pi=packed&0x1ff;if(pi==0x1ff)break;if(pi>=count)continue;displayedPlays.add(pi);Button b=new Button(this);b.setAllCaps(false);b.setText(name(PLAY+pi*PSIZE));b.setOnClickListener(v->{play=pi;status.setText("Selected play: "+name(PLAY+pi*PSIZE));});plays.addView(b);}status.setText("Formation selected • "+displayedPlays.size()+" plays");}
  void rename(boolean isFormation){int index=isFormation?formation:play;if(index<0){Toast.makeText(this,"Select a "+(isFormation?"formation":"play")+" first",Toast.LENGTH_LONG).show();return;}int field=(isFormation?FORM+index*FSIZE:PLAY+index*PSIZE);String old=name(field);EditText input=new EditText(this);input.setSingleLine(true);input.setText(old);input.selectAll();new AlertDialog.Builder(this).setTitle("Rename "+(isFormation?"formation":"play")).setView(input).setPositiveButton("Apply",(d,w)->{try{String s=input.getText().toString().trim();byte[] fresh=s.getBytes(StandardCharsets.UTF_16LE);byte[] prev=old.getBytes(StandardCharsets.UTF_16LE);if(s.isEmpty()||fresh.length>prev.length)throw new IllegalArgumentException("New name must be nonempty and no longer than "+old.length()+" UTF-16 units.");int target=field-1+u32(HEADER+field);int p=HEADER+target;Arrays.fill(data,p,p+prev.length+2,(byte)0);System.arraycopy(fresh,0,data,p,fresh.length);dirty=true;refreshFormations();if(formation>=0)selectFormation(formation);status.setText("Unsaved changes • "+s);}catch(Exception e){error(e.getMessage());}}).setNegativeButton("Cancel",null).show();}
  int signed16(int p){return (short)u16(p);}
  void put16(int p,int value){if(value < -32768 || value > 32767)throw new IllegalArgumentException("Coordinate out of range");data[p]=(byte)value;data[p+1]=(byte)(value>>>8);}
  void put32(int p,int value){for(int i=0;i<4;i++)data[p+i]=(byte)(value >>> (8*i));}

  // Real touch-driven formation editor. A working copy is used until Apply.
  // The PLAY resource is never modified by a canceled drag session.
  class FormationField extends View {
    final float[] px=new float[11], pz=new float[11];
    final Paint pen=new Paint(3);
    int active=-1;
    float scale=1f, ox, oy;
    FormationField(Context c,int base){super(c);setBackgroundColor(Color.rgb(20,78,51));
      for(int i=0;i<11;i++){px[i]=signed16(base+i*14);pz[i]=signed16(base+i*14+6);}
    }
    float fieldX(float x){return ox+x*scale;}
    float fieldY(float z){return oy-z*scale;}
    @Override protected void onDraw(Canvas c){super.onDraw(c);
      // Fit the actual eleven-player bounding box inside the available view.
      // This keeps deep backs visible on smaller Android tablet screens.
      float minX=0f,maxX=0f,minZ=0f,maxZ=0f;
      for(int i=0;i<11;i++){
        minX=Math.min(minX,px[i]);maxX=Math.max(maxX,px[i]);
        minZ=Math.min(minZ,pz[i]);maxZ=Math.max(maxZ,pz[i]);
      }
      float margin=48f;
      float availableW=Math.max(1f,getWidth()-2f*margin);
      float availableH=Math.max(1f,getHeight()-2f*margin);
      float rangeX=Math.max(1000f,maxX-minX);
      float rangeZ=Math.max(1800f,maxZ-minZ);
      scale=Math.min(availableW/rangeX,availableH/rangeZ);
      ox=getWidth()/2f-(minX+maxX)*.5f*scale;
      oy=getHeight()/2f+(minZ+maxZ)*.5f*scale;
      pen.setStrokeWidth(2);pen.setColor(0x55ffffff);
      for(int yard=-20;yard<=20;yard+=5){float y=fieldY(yard*91.44f);c.drawLine(0,y,getWidth(),y,pen);}
      c.drawLine(0,oy,getWidth(),oy,pen);
      pen.setTextSize(28);pen.setTextAlign(Paint.Align.CENTER);
      for(int i=0;i<11;i++){
        float x=fieldX(px[i]),y=fieldY(pz[i]);pen.setColor(i==active?Color.YELLOW:Color.WHITE);c.drawCircle(x,y,22,pen);
        pen.setColor(Color.BLACK);c.drawText(""+(i+1),x,y+9,pen);
      }
      pen.setTextAlign(Paint.Align.LEFT);pen.setColor(Color.WHITE);pen.setTextSize(24);
      c.drawText("LOS",12,oy-10,pen);
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){
      float x=e.getX(),y=e.getY();
      if(e.getActionMasked()==MotionEvent.ACTION_DOWN){
        float best=65*65;active=-1;
        for(int i=0;i<11;i++){float dx=x-fieldX(px[i]),dy=y-fieldY(pz[i]);float d=dx*dx+dy*dy;if(d<best){best=d;active=i;}}
        invalidate();return true;
      }
      if(e.getActionMasked()==MotionEvent.ACTION_MOVE && active>=0){
        px[active]=Math.max(-32768,Math.min(32767,Math.round((x-ox)/scale)));
        pz[active]=Math.max(-32768,Math.min(32767,Math.round((oy-y)/scale)));
        invalidate();return true;
      }
      if(e.getActionMasked()==MotionEvent.ACTION_UP){active=-1;invalidate();return true;}
      return true;
    }
  }
  void showFormationField(){
    if(formation<0){Toast.makeText(this,"Select a formation first",Toast.LENGTH_LONG).show();return;}
    final int selected=formation, base=HEADER+FORM+formation*FSIZE+0x1A;
    final FormationField field=new FormationField(this,base);
    LinearLayout content=vertical();content.addView(label("Drag a numbered player to reposition. Tap APPLY to commit; CANCEL discards the changes.",14));
    int displayHeight=getResources().getDisplayMetrics().heightPixels;
    int editorHeight=Math.max(280,Math.min(650,(int)(displayHeight*.52f)));
    content.addView(field,new LinearLayout.LayoutParams(-1,editorHeight));
    new AlertDialog.Builder(this).setTitle("Formation Field — "+name(FORM+selected*FSIZE))
      .setView(content).setPositiveButton("APPLY",(d,w)->{
        for(int i=0;i<11;i++){put16(base+i*14,Math.round(field.px[i]));put16(base+i*14+6,Math.round(field.pz[i]));}
        dirty=true;status.setText("Formation positions updated • unsaved");
      }).setNegativeButton("CANCEL",null).show();
  }


  // NFL 2K4 route instructions: opcode 0x12, packed segment type in bits 0-3,
  // flag in bit 4, distance in high byte (cm/30.48, nearest yard), extra in bits 20-23.
  // Editing uses copy-on-write so no other play or receiver can be changed by shared nodes.
  static final int NODE=0x9ADC, STRING=0x10840, NODE_BYTES=8, MAX_NODES=(STRING-NODE)/NODE_BYTES;
  int[] routeOffset(int kind,int yards,int side){
    double inward=side>=0?-1:1, a=0;double x=0,y=0;
    if(kind==1)a=30;else if(kind==2)a=45;else if(kind==3)a=60;else if(kind==6)a=-45;
    if(a!=0){x=inward*yards*Math.sin(Math.toRadians(a));y=yards*Math.cos(Math.toRadians(a));}
    else if(kind==4)x=inward*yards;else if(kind==5)x=-inward*yards;else y=yards;
    return new int[]{(int)Math.round(x*91.44),(int)Math.round(y*91.44)};
  }
  class RouteField extends View{
    final Paint pen=new Paint(3);final ArrayList<float[]> points=new ArrayList<>();
    final float startX,startZ;float scale,ox,oy;
    RouteField(Context c,float x,float z){super(c);startX=x;startZ=z;setBackgroundColor(Color.rgb(20,78,51));}
    @Override protected void onDraw(Canvas c){super.onDraw(c);scale=Math.min(getWidth()/3000f,getHeight()/3200f);ox=getWidth()/2f;oy=getHeight()*.83f;
      pen.setColor(0x66ffffff);pen.setStrokeWidth(2);for(int i=-10;i<=35;i+=5){float y=oy-i*91.44f*scale;c.drawLine(0,y,getWidth(),y,pen);}
      pen.setColor(Color.WHITE);pen.setStrokeWidth(4);c.drawLine(0,oy,getWidth(),oy,pen);
      pen.setColor(Color.YELLOW);c.drawCircle(ox+startX*scale,oy-startZ*scale,17,pen);
      float lastX=ox+startX*scale,lastY=oy-startZ*scale;
      for(float[] point:points){float x=ox+point[0]*scale,y=oy-point[1]*scale;pen.setColor(Color.CYAN);pen.setStrokeWidth(6);c.drawLine(lastX,lastY,x,y,pen);c.drawCircle(x,y,12,pen);lastX=x;lastY=y;}
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getActionMasked()==MotionEvent.ACTION_UP){points.add(new float[]{(e.getX()-ox)/scale,(oy-e.getY())/scale});invalidate();performClick();return true;}return true;}
    @Override public boolean performClick(){super.performClick();return true;}
  }
  void showRouteEditor(){
    if(play<0||formation<0){Toast.makeText(this,"Select a formation and play",Toast.LENGTH_LONG).show();return;}
    final int selectedPlay=play, selectedFormation=formation;
    LinearLayout content=vertical();Spinner receiver=new Spinner(this);String[] slots=new String[11];for(int i=0;i<11;i++)slots[i]="Player "+(i+1);
    receiver.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,slots));content.addView(receiver);
    TextView hint=label("Tap successive route breakpoints. Only supported NFL 2K4 segment angles will be encoded. Undo removes the last point.",14);content.addView(hint);
    final LinearLayout holder=vertical();content.addView(holder);
    final RouteField[] field={null};
    Runnable reset=()->{holder.removeAllViews();int slot=receiver.getSelectedItemPosition();int pos=HEADER+FORM+selectedFormation*FSIZE+0x1A+slot*14;
      field[0]=new RouteField(this,signed16(pos),signed16(pos+6));holder.addView(field[0],new LinearLayout.LayoutParams(-1,600));};
    receiver.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){reset.run();}});
    reset.run();Button undo=new Button(this);undo.setText("UNDO LAST BREAKPOINT");undo.setOnClickListener(v->{if(field[0]!=null&&!field[0].points.isEmpty()){field[0].points.remove(field[0].points.size()-1);field[0].invalidate();}});content.addView(undo);
    ScrollView scroll=new ScrollView(this);scroll.addView(content);
    new AlertDialog.Builder(this).setTitle("Draw Route — "+name(PLAY+selectedPlay*PSIZE)).setView(scroll)
      .setPositiveButton("APPLY TO SESSION",(d,w)->{try{writeRoute(selectedPlay,receiver.getSelectedItemPosition(),field[0]);dirty=true;status.setText("Route updated • unsaved PLAY");}catch(Exception ex){error("Route not applied: "+ex.getMessage());}})
      .setNegativeButton("CANCEL",null).show();
  }
  void writeRoute(int pi,int slot,RouteField field){
    if(field==null||field.points.isEmpty())throw new IllegalArgumentException("Draw at least one breakpoint");
    int descriptor=HEADER+PLAY+pi*PSIZE+8+slot*8, pointer=descriptor+4;
    int oldDescriptor=u32(descriptor), length=oldDescriptor&15;
    if(length<1||length>15)throw new IllegalArgumentException("Invalid assignment length");
    int relative=u32(pointer), nodeAt=(pointer-HEADER)-1+relative;
    if(nodeAt<NODE||(nodeAt-NODE)%8!=0)throw new IllegalArgumentException("Invalid assignment pointer");
    int oldStart=(nodeAt-NODE)/8, active=u32(HEADER+0x40);
    if(oldStart+length>active||active>MAX_NODES)throw new IllegalArgumentException("Invalid node table");
    ArrayList<byte[]> output=new ArrayList<>();
    // Keep original setup instructions (start, motion, release), replacing only route execution.
    for(int i=0;i<length;i++){int at=HEADER+NODE+(oldStart+i)*8, op=data[at]&255;
      if(op==1||op==2||op==3){output.add(Arrays.copyOfRange(data,at,at+8));}else break;}
    if(output.isEmpty())throw new IllegalArgumentException("This receiver has no supported setup node; route edit refused");
    float x=field.startX,z=field.startZ;int side=x<-15.24f?-1:1;
    for(float[] point:field.points){double dx=point[0]-x,dy=point[1]-z;if(Math.hypot(dx,dy)<32)continue;
      double best=Double.POSITIVE_INFINITY;int bestKind=-1,bestYards=0,bx=0,by=0;
      for(int kind:new int[]{0,1,2,3,4,5,6})for(int yd=1;yd<=100;yd++){
        int[] vec=routeOffset(kind,yd,side);double err=Math.hypot(dx-vec[0],dy-vec[1]);if(err<best){best=err;bestKind=kind;bestYards=yd;bx=vec[0];by=vec[1];}}
      if(best>Math.max(2*91.44,Math.hypot(dx,dy)*.48))throw new IllegalArgumentException("Waypoint cannot be represented by stock route angles");
      int distByte=Math.max(1,Math.min(255,(int)Math.round(bestYards*91.44/30.48)));
      int packed=bestKind|(15<<20)|(distByte<<24);
      byte[] node=new byte[8];node[0]=0x12;for(int k=0;k<4;k++)node[4+k]=(byte)(packed>>>(8*k));output.add(node);x+=bx;z+=by;
    }
    if(output.size()<=1||output.size()>15)throw new IllegalArgumentException("Route needs 1–15 total instructions");
    if(active+output.size()>MAX_NODES)throw new IllegalArgumentException("No free assignment node space");
    // Clear terminal flag from copied setup nodes; only final route node terminates.
    for(byte[] node:output)node[1]=(byte)(node[1]&~2);
    output.get(output.size()-1)[1]|=2;
    int newStart=active;for(int i=0;i<output.size();i++)System.arraycopy(output.get(i),0,data,HEADER+NODE+(newStart+i)*8,8);
    int newTarget=NODE+newStart*8;put32(pointer,newTarget-((pointer-HEADER)-1));
    put32(descriptor,(oldDescriptor&~15)|output.size());put32(HEADER+0x40,active+output.size());
    // Verify descriptor and pointer roundtrip before declaring success.
    if((u32(descriptor)&15)!=output.size()||((pointer-HEADER)-1+u32(pointer))!=newTarget)throw new IllegalStateException("Route pointer verification failed");
  }

  void editPositions(){
    if(formation<0){Toast.makeText(this,"Select a formation first",Toast.LENGTH_LONG).show();return;}
    final int selected=formation;
    final int base=HEADER+FORM+selected*FSIZE+0x1A;
    ScrollView scroll=new ScrollView(this);LinearLayout content=vertical();scroll.addView(content);
    content.addView(label("Player coordinates in centimeters. Only primary X/Z are edited; other formation bytes are preserved.",14));
    final EditText[] xs=new EditText[11], zs=new EditText[11];
    for(int i=0;i<11;i++){
      int slot=base+i*14;
      LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
      TextView tag=label("Player "+(i+1),14);row.addView(tag,new LinearLayout.LayoutParams(0,-2,1));
      xs[i]=new EditText(this);xs[i].setSingleLine(true);xs[i].setInputType(8194);xs[i].setText(""+signed16(slot));row.addView(xs[i],new LinearLayout.LayoutParams(0,-2,1));
      zs[i]=new EditText(this);zs[i].setSingleLine(true);zs[i].setInputType(8194);zs[i].setText(""+signed16(slot+6));row.addView(zs[i],new LinearLayout.LayoutParams(0,-2,1));
      content.addView(row);
    }
    new AlertDialog.Builder(this).setTitle("Formation Positions — X / Z").setView(scroll).setPositiveButton("Apply to session",(d,w)->{
      try{
        int[] x=new int[11],z=new int[11];for(int i=0;i<11;i++){x[i]=Integer.parseInt(xs[i].getText().toString().trim());z[i]=Integer.parseInt(zs[i].getText().toString().trim());if(x[i]<-32768||x[i]>32767||z[i]<-32768||z[i]>32767)throw new IllegalArgumentException("Player "+(i+1)+" out of range");}
        for(int i=0;i<11;i++){int slot=base+i*14;put16(slot,x[i]);put16(slot+6,z[i]);}
        dirty=true;status.setText("Unsaved formation position changes — "+name(FORM+selected*FSIZE));
      }catch(Exception e){error(e.toString());}
    }).setNegativeButton("Cancel",null).show();
  }
  void editPlayClass(){
    if(play<0){Toast.makeText(this,"Select a play first",Toast.LENGTH_LONG).show();return;}
    final int selected=play;final int off=HEADER+PLAY+selected*PSIZE+4;
    int flags=u32(off);String current=(flags&0x04000000)!=0?"90-series candidate":(flags&0x00004000)!=0?"50-series candidate":"Other";
    new AlertDialog.Builder(this).setTitle("Experimental 50/90 Play Class").setMessage("Current: "+current+". This changes only the two candidate classification bits. In-game dropback effect is unverified.")
      .setItems(new String[]{"90-series candidate","50-series candidate"},(d,which)->{
        int original=u32(off);int changed=(original & ~0x04004000) | (which==0?0x04000000:0x00004000);
        put32(off,changed);dirty=true;status.setText("Unsaved play class edit — "+name(PLAY+selected*PSIZE));
      }).setNegativeButton("Cancel",null).show();
  }
  void save(){if(data==null)return;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE, filename.replace(".PLAY","_edited.PLAY"));startActivityForResult(i,42);}
  void chooseIso(){
    if(patchBusy)return;
    if(data==null||filename.isEmpty()){error("Choose a base PLAY first.");return;}
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
    i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    startActivityForResult(i,REQUEST_ISO);
  }
  void choosePatchedIso(){
    Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
    i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);
    i.putExtra(Intent.EXTRA_TITLE,"NFL2K4_"+filename.split("_",2)[0]+"_patched.iso");
    startActivityForResult(i,REQUEST_PATCHED_ISO);
  }
  @Override protected void onActivityResult(int request,int result,Intent intent){
    super.onActivityResult(request,result,intent);
    if(result!=RESULT_OK||intent==null||intent.getData()==null)return;
    Uri uri=intent.getData();
    if(request==42){try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
      if(out==null)throw new IOException("Could not open output PLAY file");out.write(data);
      dirty=false;status.setText("Saved PLAY • "+uri.getLastPathSegment());
    }catch(Exception e){error(e.toString());}return;}
    if(request==REQUEST_ISO){selectedIso=uri;choosePatchedIso();return;}
    if(request==REQUEST_PATCHED_ISO){
      if(selectedIso.equals(uri)){error("Input and output ISO must be different files.");return;}
      final Uri input=selectedIso, output=uri;
      final byte[] edited=Arrays.copyOf(data,data.length);
      final String base=filename;
      patchBusy=true;status.setText("Patching ISO in background — do not close the app…");
      new Thread(()->{
        try{long off=patchIso(input,output,base,edited);
          runOnUiThread(()->{patchBusy=false;status.setText("Patched ISO created • offset 0x"+Long.toHexString(off).toUpperCase(Locale.ROOT));
            new AlertDialog.Builder(this).setTitle("ISO patch complete").setMessage("Original ISO was not modified.\nPatched resource at 0x"+Long.toHexString(off).toUpperCase(Locale.ROOT)+"\nTest the new ISO in PCSX2.").setPositiveButton("OK",null).show();});
        }catch(Exception e){runOnUiThread(()->{patchBusy=false;error("ISO patch failed: "+e.getMessage()+". Delete the incomplete output ISO.");});}
      }).start();
    }
  }
  long patchIso(Uri source,Uri destination,String baseName,byte[] modified)throws Exception{
    byte[] original;
    try(InputStream a=getAssets().open("playbooks/"+baseName);ByteArrayOutputStream b=new ByteArrayOutputStream()){
      byte[] buf=new byte[8192];int n;while((n=a.read(buf))!=-1)b.write(buf,0,n);original=b.toByteArray();
    }
    if(original.length!=modified.length||original.length<32||original[0]!='P'||original[1]!='L'||original[2]!='A'||original[3]!='Y'||modified[0]!='P'||modified[1]!='L'||modified[2]!='A'||modified[3]!='Y')
      throw new IOException("Original and edited PLAY resources must have identical valid sizes");
    if(Arrays.equals(original,modified))throw new IOException("No PLAY changes to patch");
    java.util.regex.Matcher m=java.util.regex.Pattern.compile("_offset_([0-9A-Fa-f]+)\\.PLAY$").matcher(baseName);
    if(!m.find())throw new IOException("Bundled PLAY filename has no ISO offset");
    long offset=Long.parseLong(m.group(1),16);
    if(offset<0)throw new IOException("Invalid ISO offset");
    // SAF streams work on external storage and do not require loading a multi-GB ISO into RAM.
    // Validate the original PLAY bytes at the expected offset before creating output.
    long size=0;
    try(InputStream in=getContentResolver().openInputStream(source)){
      if(in==null)throw new IOException("Could not read source ISO");
      byte[] buf=new byte[1024*1024];long remaining=offset;
      while(remaining>0){int n=in.read(buf,0,(int)Math.min(buf.length,remaining));if(n<0)throw new IOException("ISO shorter than expected PLAY offset");if(n==0)continue;remaining-=n;}
      byte[] found=new byte[original.length];readFully(in,found);
      if(!Arrays.equals(found,original))throw new IOException("Original PLAY bytes do not match selected ISO at offset 0x"+Long.toHexString(offset)+". Select the matching unmodified ISO.");
    }
    try(InputStream in=getContentResolver().openInputStream(source);OutputStream out=getContentResolver().openOutputStream(destination,"wt")){
      if(in==null||out==null)throw new IOException("Unable to open ISO streams");
      byte[] buf=new byte[1024*1024];long pos=0;int n;
      while((n=in.read(buf))!=-1){if(n==0)continue;
        int start=0;
        while(start<n){
          long absolute=pos+start;
          if(absolute>=offset&&absolute<offset+original.length){
            int take=(int)Math.min(n-start,offset+original.length-absolute);
            out.write(modified,(int)(absolute-offset),take);start+=take;
          }else{
            int take=(int)Math.min(n-start,absolute<offset?offset-absolute:Long.MAX_VALUE);
            out.write(buf,start,take);start+=take;
          }
        }
        pos+=n;
      }
      size=pos;out.flush();
    }
    if(size<offset+original.length)throw new IOException("Source ISO truncated while copying");
    // Read back the patched region and verify the entire output size.
    try(InputStream in=getContentResolver().openInputStream(destination)){
      if(in==null)throw new IOException("Unable to verify output ISO");
      byte[] buf=new byte[1024*1024];long remaining=offset;
      while(remaining>0){int n=in.read(buf,0,(int)Math.min(buf.length,remaining));if(n<0)throw new IOException("Patched ISO truncated");if(n==0)continue;remaining-=n;}
      byte[] check=new byte[modified.length];readFully(in,check);
      if(!Arrays.equals(check,modified))throw new IOException("Patched PLAY readback mismatch");
      long total=offset+modified.length;int n;while((n=in.read(buf))!=-1)total+=n;
      if(total!=size)throw new IOException("Output ISO length mismatch");
    }
    return offset;
  }
  static void readFully(InputStream in,byte[] dst)throws IOException{
    int at=0;while(at<dst.length){int n=in.read(dst,at,dst.length-at);if(n<0)throw new EOFException("ISO ended during PLAY read");if(n==0)continue;at+=n;}
  }
  @Override public void onBackPressed(){if(!dirty){super.onBackPressed();return;}new AlertDialog.Builder(this).setTitle("Unsaved changes").setMessage("Exit without saving?").setPositiveButton("Discard",(d,w)->finish()).setNegativeButton("Stay",null).show();}
}
